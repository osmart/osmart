This directory contains. A number of directories with input
files for hole runs on gramicidin, cholera toxin B5 and
maltoporin structures.

The idea is that you should use these files to perform
"follow me" runs. The
The examples tutorial can be found on the web at 
http://hole.biop.ox.ac.uk/hole/help
